const mongoose = require("mongoose");
const { response } = require("express");
//mongoose schema 
const guser =new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
                type:String,
                 required:true,
                
            },
     token:{
        type:Number,
        
            },
      password:{
          type:Number,
          default:"03032000",

      }      
                              
})

const Guser = new  mongoose.model("google_user",guser);

module.exports = Guser;