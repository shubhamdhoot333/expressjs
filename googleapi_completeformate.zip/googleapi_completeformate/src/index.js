//requires package 
const passport = require('passport');
const googleStrategy = require('passport-google-oauth20');
const express = require("express");
const app = express();
const path =require("path");
const hbs = require("hbs");
//const cookieParser = require('cookie-parser'); 
const port = process.env.PORT || 3000
require("./db/conn");
const Guser = require("./models/user");
const { json } = require("express");
const { log } = require("console");

//built in middleware
const staticPath =path.join(__dirname,"../public");
const templatePath =path.join(__dirname,"../templates/views");
const partialsPath =path.join(__dirname,"../templates/partials");
// to set the view enginee
app.set('view engine','hbs');
app.set("views",templatePath);
//register the hbs
hbs.registerPartials(partialsPath);
app.use(express.static(staticPath));

//it through get the data from form and convert to json formate 
app.use(express.json());
app.use(passport.initialize());
//it means it not show undefind data it show properly data 
app.use(express.urlencoded({extended:false}));

passport.use(new googleStrategy({
    clientID:'893794495903-0bnu8m7esd0bilm3670ct5ac43vnctf9.apps.googleusercontent.com' ,
    clientSecret:'OGfv6-VImpRL2mRV09z7Ouq5',
    callbackURL: "http://localhost:3000/auth/google/callback"
  },function(accessToken, refreshToken, profile, done) {
    userProfile=profile;
    return done(null, userProfile);
      
}, ))
app.get("/login",(req,res) =>{
  res.render("login");

});

app.get('/success', async (req, res) =>
{

  try{
      
    const guse = new Guser({
     
      name:userProfile._json.name,
        email:userProfile._json.email,
        token:userProfile._json.sub,
        
    }) 

    const result2 = await Guser.findOne({email:userProfile._json.email})
    
     if(result2)
     {
        
        res.render("user",{"user":userProfile._json.email}); 
     }
     else
     {
        const result = await guse.save();
        res.render("user",{"user":userProfile._json.email});
     }       
}
catch(error){
res.status(400).send(error);
}
 });

 

 app.get('/error', (req, res) => res.send("error logging in"));
passport.serializeUser(function(user, cb) {
  cb(null, user);
});

passport.deserializeUser(function(obj, cb) {
  cb(null, obj);
});



app.get("/",(req,res) => {
   res.render("register");
});

app.get('/auth/google', 
  passport.authenticate('google', { scope : ['profile', 'email'] }));
 
app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/error' }),
  function(req, res) {
    // Successful authentication, redirect success.
    res.redirect('/success');
  });


 



app.listen(port, (req,res ) =>{
    console.log(`post number ${port}`);
});